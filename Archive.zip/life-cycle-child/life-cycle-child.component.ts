import { AfterContentChecked, AfterContentInit, AfterViewChecked, AfterViewInit, Component, ContentChild, DoCheck, Input, OnChanges, OnDestroy, OnInit, SimpleChanges, ViewChild } from '@angular/core';

@Component({
  selector: 'app-life-cycle-child',
  templateUrl: './life-cycle-child.component.html',
  styleUrls: ['./life-cycle-child.component.css']
})
export class LifeCycleChildComponent implements OnInit, OnDestroy, OnChanges, DoCheck, AfterContentInit, AfterContentChecked, AfterViewInit, AfterViewChecked  {

  counter : number=0;
  //interval: any;

  @ContentChild('projectedContent') projectedContent: any;

  @ViewChild('childContent',{static:true}) childContent: any;
  
  constructor() { 
    console.log('ChildComponent constructor()');

  }
  ngAfterViewInit(): void {
    console.log('\t\t\tChildComponent ngAfterViewInit()'); //once after first ng content checked
    console.log('childContent : '+this.childContent);
  }
  ngAfterViewChecked(): void {
    console.log('\t\t\tChildComponent ngAfterViewChecked()'); //after ngafterviewInit    | then  subsequence afterContentChecked
    console.log('childContent : '+this.childContent);

  }
  ngAfterContentChecked(): void {
    console.log('\t\tChildComponent ngAfterContentChecked()');
    console.log('childContent : '+this.childContent);

  }
  ngAfterContentInit(): void {
    console.log('ChildComponent ngAfterContentInit()');
    console.log('ngAfterContentInit() : projectedContent : '+this.projectedContent);
    console.log('childContent : '+this.childContent);

  }
  ngDoCheck(): void {
    console.log('ChildComponent ngDoCheck()');
    console.log('ngDoCheck() : projectedContent : '+this.projectedContent);
    console.log('childContent : '+this.childContent);

  }
  ngOnChanges(changes: SimpleChanges): void {
    console.log('ChildComponent ngOnChanges()'); // not a good practice to call any API operations here, since during each change detection of the child this method is invoked...
    console.log(changes); // observe the prev and new changes
    console.log('ngOnChanges() : projectedContent :  '+this.projectedContent);
    console.log('childContent : '+this.childContent);

  }

  ngOnDestroy(): void {
    console.log('ChildComponent ngOnDestroy()');
   //clearInterval(this.interval); 
   console.log('ngOnDestroy() : projectedContent :  '+this.projectedContent);
   console.log('childContent : '+this.childContent);

  }

  ngOnInit(): void {
    console.log('ChildComponent ngOnInit()');
    console.log('ngOnInit() : projectedContent :  '+this.projectedContent);
    console.log('childContent : '+this.childContent);

    /*this.interval = setInterval(()=> {
      this.counter+=1;
      console.log(this.counter);
    },1000);*/
  }

  companyName: string='';

  @Input()
  companyName2: string='';
}
