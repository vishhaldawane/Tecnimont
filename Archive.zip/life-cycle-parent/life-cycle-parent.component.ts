import { Component, DoCheck, OnInit } from '@angular/core';

@Component({
  selector: 'app-life-cycle-parent',
  templateUrl: './life-cycle-parent.component.html',
  styleUrls: ['./life-cycle-parent.component.css']
})
export class LifeCycleParentComponent implements OnInit, DoCheck {

  constructor() { 
    console.log('ParentComponent constructor()');
  }
  ngDoCheck(): void {
    console.log('ParentComponent ngDoCheck()');
  }

  ngOnInit(): void {
    console.log('ParentComponent ngOnInit()');
  }

  companyName2:string='';
  
  isChild: boolean = false;

  toggleChild() {
    this.isChild=!this.isChild;
  }

}
