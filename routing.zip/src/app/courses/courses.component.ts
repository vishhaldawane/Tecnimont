import { Component, OnInit } from '@angular/core';
import { CoursesService } from '../Services/courses.service';

@Component({
  selector: 'app-courses',
  templateUrl: './courses.component.html',
  styleUrls: ['./courses.component.css']
})
export class CoursesComponent implements OnInit {

  constructor(private coursesService: CoursesService) { }

//  courses = [];
  crs: any[]=[]; //is referred by the html file of this component


  ngOnInit(): void {
    this.crs = this.coursesService.courses;//let the original service's class array to be fetched
  }

}
