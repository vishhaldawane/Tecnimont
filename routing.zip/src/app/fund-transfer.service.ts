import { Injectable } from '@angular/core';
import { SavingsAccount } from './fund-transfer/SavingsAccount';

@Injectable({
  providedIn: 'root'
})
export class FundTransferService {

  constructor() { }

  transferFunds(source: SavingsAccount, target: SavingsAccount, amtToTransfer: number) {
    source.accountBalance-=amtToTransfer;
    target.accountBalance+=amtToTransfer;
    console.log('AMT TRANSFERRED VIA SERVICE');
  }
}
