export class SavingsAccount { //1
    accountNumber: number=0;
    accountHolder: string="";
    accountBalance:number=0;
}