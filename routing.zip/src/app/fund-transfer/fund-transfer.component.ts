import { Component, OnInit } from '@angular/core';
import { SavingsAccount } from './SavingsAccount';
import { FundTransferService } from '../fund-transfer.service';

@Component({
  selector: 'app-fund-transfer',
  templateUrl: './fund-transfer.component.html',
  styleUrls: ['./fund-transfer.component.css']
})
export class FundTransferComponent implements OnInit { //3 interface

  constructor(private fts: FundTransferService) {
    
   }

  ngOnInit(): void {
    this.source.accountNumber=101;
    this.source.accountHolder="Jack";
    this.source.accountBalance=50000;

    this.target.accountNumber=102;
    this.target.accountHolder="Janet";
    this.target.accountBalance=60000;
  }

  //2 make 2 objects of SavingsAccount
  source: SavingsAccount = { accountNumber:101,accountHolder:'Jim',accountBalance:50000};
  target: SavingsAccount = { accountNumber:102,accountHolder:'Janet',accountBalance:60000};
  message: string="";
  amountToTransfer: number=0;
 
  localTransfer() {
    if(this.amountToTransfer<=0) {
      this.message='Tranfser amount cannot be zero or negative';
    }
    else if(this.source.accountBalance < this.amountToTransfer) {
      this.message='Insufficient balance at source';
    }
    else {
      /*this.source.accountBalance-=this.amountToTransfer;
      this.target.accountBalance+=this.amountToTransfer;*/
      this.fts.transferFunds(this.source,this.target,this.amountToTransfer);
      this.message='Transfer successfull';
    }
  }

}
